package com.mycompany.gerenciamentoconsultas;

import com.mycompany.gerenciamentoconsultas.views.TelaGerenciamento;

public class GerenciamentoConsultas {

    public static void main(String[] args) {
        TelaGerenciamento tela = new TelaGerenciamento();
        tela.setVisible(true);

    }
}
